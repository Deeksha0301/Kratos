package com.example.kratos.entities

import androidx.room.Entity


@Entity(tableName = )
data class Recipies()
